import React, { useState, useRef, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  TouchableOpacity, 
  Image, 
  TextInput, 
  Modal,
  Alert,
  Animated,
  Dimensions,
  ActivityIndicator,
  FlatList
} from 'react-native';
import { 
  Heart, 
  MessageCircle, 
  Share, 
  MoreHorizontal, 
  Filter, 
  Send, 
  X, 
  Flag, 
  UserX, 
  EyeOff, 
  BarChart2,
  User,
  Mail,
  ChevronDown,
  ChevronUp
} from 'lucide-react-native';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { LineChart, BarChart } from 'react-native-chart-kit';

const { width } = Dimensions.get('window');

interface UserProfile {
  id: string;
  name: string;
  title: string;
  avatar: string;
  isFollowing: boolean;
  company: string;
  followers: number;
  following: number;
  about: string;
  joinedDate: string;
}

interface Post {
  id: string;
  user: UserProfile;
  content: string;
  image?: string;
  likes: number;
  comments: Comment[];
  isLiked: boolean;
  timeAgo: string;
  category: string;
  shares: number;
  views: number;
}

interface Comment {
  id: string;
  user: {
    id: string;
    name: string;
    avatar: string;
  };
  text: string;
  timeAgo: string;
  likes: number;
  isLiked: boolean;
}

interface CompanyGrowthData {
  labels: string[];
  revenue: number[];
  users: number[];
  employees: number[];
}

const mockUsers: UserProfile[] = [
  {
    id: 'user1',
    name: 'Sarah Chen',
    title: 'Co-founder at EcoTrack',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    isFollowing: false,
    company: 'EcoTrack',
    followers: 1243,
    following: 567,
    about: 'Building sustainable solutions for supply chain management. Passionate about reducing carbon footprints through technology.',
    joinedDate: 'March 2020'
  },
  {
    id: 'user2',
    name: 'David Rodriguez',
    title: 'Founder at HealthAI',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    isFollowing: true,
    company: 'HealthAI',
    followers: 2890,
    following: 342,
    about: 'AI enthusiast transforming healthcare diagnostics. Series A funded. Always looking for talented engineers to join our mission.',
    joinedDate: 'January 2019'
  },
  {
    id: 'user3',
    name: 'Emily Zhang',
    title: 'CEO at TechFlow',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    isFollowing: false,
    company: 'TechFlow',
    followers: 876,
    following: 1023,
    about: 'Building developer tools that make workflows seamless. Open source contributor. Speaker at tech conferences worldwide.',
    joinedDate: 'November 2021'
  }
];

const mockPosts: Post[] = [
  {
    id: 'post1',
    user: mockUsers[0],
    content: 'Thrilled to share our progress in making supply chains sustainable! 🌱 EcoTrack helps businesses reduce their carbon footprint through real-time monitoring. Check out our growth metrics below!',
    image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
    likes: 124,
    comments: [
      {
        id: 'comment1',
        user: {
          id: 'user2',
          name: 'David Rodriguez',
          avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
        },
        text: 'This is amazing! How can I get involved? We should discuss potential collaborations.',
        timeAgo: '2h',
        likes: 3,
        isLiked: false
      },
      {
        id: 'comment2',
        user: {
          id: 'user4',
          name: 'Emily Zhang',
          avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
        },
        text: 'Love the sustainability focus! 🌍 The metrics look impressive - 200% YoY growth is no small feat!',
        timeAgo: '1h',
        likes: 8,
        isLiked: true
      },
    ],
    isLiked: false,
    timeAgo: '2h',
    category: 'Success Story',
    shares: 24,
    views: 456
  },
  {
    id: 'post2',
    user: mockUsers[1],
    content: 'Just closed our Series A! $15M raised to revolutionize patient diagnostics. Thank you to all our investors who believe in AI-powered healthcare. Next stop: FDA approval! 🚀',
    likes: 89,
    comments: [
      {
        id: 'comment3',
        user: {
          id: 'user1',
          name: 'Sarah Chen',
          avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
        },
        text: 'Congratulations! Well deserved 🎉 The healthcare space needs more innovation like yours.',
        timeAgo: '3h',
        likes: 5,
        isLiked: false
      },
    ],
    isLiked: true,
    timeAgo: '4h',
    category: 'Milestone',
    shares: 12,
    views: 289
  },
  {
    id: 'post3',
    user: mockUsers[2],
    content: 'Building in public: Here\'s what we learned from our first 1000 users. The feedback has been incredible and shaped our product roadmap. Key takeaways: 1) Performance is critical 2) Documentation needs work 3) Users want more integrations',
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
    likes: 67,
    comments: [],
    isLiked: false,
    timeAgo: '6h',
    category: 'Insights',
    shares: 8,
    views: 178
  }
];

const companyGrowthData: CompanyGrowthData = {
  labels: ['2019', '2020', '2021', '2022', '2023'],
  revenue: [0.5, 1.2, 2.8, 5.4, 12.7], // in millions
  users: [120, 450, 1200, 3500, 9800],
  employees: [5, 12, 28, 45, 82]
};

const chartConfig = {
  backgroundColor: '#ffffff',
  backgroundGradientFrom: '#ffffff',
  backgroundGradientTo: '#ffffff',
  decimalPlaces: 1,
  color: (opacity = 1) => `rgba(59, 130, 246, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(30, 41, 59, ${opacity})`,
  style: {
    borderRadius: 16
  },
  propsForDots: {
    r: '4',
    strokeWidth: '2',
    stroke: '#3B82F6'
  }
};

export default function SocialFeedScreen() {
  const [posts, setPosts] = useState<Post[]>(mockPosts);
  const [selectedFilter, setSelectedFilter] = useState('All');
  const [showComments, setShowComments] = useState<string | null>(null);
  const [showOptions, setShowOptions] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [showShareModal, setShowShareModal] = useState<string | null>(null);
  const [showGrowthData, setShowGrowthData] = useState<string | null>('post1');
  const [loading, setLoading] = useState(false);
  const [reportReason, setReportReason] = useState('');
  const [showReportModal, setShowReportModal] = useState<string | null>(null);
  
  // Animation values
  const likeAnimation = useRef(new Animated.Value(1)).current;
  const slideAnimation = useRef(new Animated.Value(0)).current;

  const filters = ['All', 'Success Story', 'Milestone', 'Insights', 'Trending'];

  const animateLike = () => {
    Animated.sequence([
      Animated.timing(likeAnimation, {
        toValue: 1.3,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(likeAnimation, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handleLike = (postId: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    animateLike();
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            isLiked: !post.isLiked, 
            likes: post.isLiked ? post.likes - 1 : post.likes + 1 
          }
        : post
    ));
  };

  const handleCommentLike = (postId: string, commentId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const updatedComments = post.comments.map(comment => {
          if (comment.id === commentId) {
            return {
              ...comment,
              isLiked: !comment.isLiked,
              likes: comment.isLiked ? comment.likes - 1 : comment.likes + 1
            };
          }
          return comment;
        });
        return { ...post, comments: updatedComments };
      }
      return post;
    }));
  };

  const handleFollow = (userId: string) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setPosts(posts.map(post => 
      post.user.id === userId
        ? { 
            ...post, 
            user: { ...post.user, isFollowing: !post.user.isFollowing }
          }
        : post
    ));
  };

  const handleComment = (postId: string) => {
    if (!commentText.trim()) return;
    
    const newComment: Comment = {
      id: Date.now().toString(),
      user: {
        id: 'currentUser',
        name: 'You',
        avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop',
      },
      text: commentText,
      timeAgo: 'now',
      likes: 0,
      isLiked: false
    };

    setPosts(posts.map(post =>
      post.id === postId
        ? { ...post, comments: [...post.comments, newComment] }
        : post
    ));
    setCommentText('');
  };

  const handleShare = (postId: string) => {
    Haptics.selectionAsync();
    setShowShareModal(postId);
  };

  const handleReport = (postId: string) => {
    setShowReportModal(postId);
    setShowOptions(null);
  };

  const submitReport = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setShowReportModal(null);
      setReportReason('');
      Alert.alert('Report Submitted', 'Thank you for helping improve our community. We will review this content shortly.');
    }, 1500);
  };

  const handleBlock = (userId: string) => {
    Alert.alert(
      'Block User',
      `Are you sure you want to block ${mockUsers.find(u => u.id === userId)?.name}? You won't see their posts or messages.`,
      [
        { 
          text: 'Block', 
          style: 'destructive',
          onPress: () => {
            setPosts(posts.filter(post => post.user.id !== userId));
            Alert.alert('User Blocked', 'This user has been blocked and their content will no longer appear in your feed.');
          }
        },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
    setShowOptions(null);
  };

  const handleHidePost = (postId: string) => {
    setPosts(posts.filter(post => post.id !== postId));
    Alert.alert('Post Hidden', 'This post has been hidden from your feed.');
    setShowOptions(null);
  };

  const openProfile = (userId: string) => {
    router.push({
      pathname: '/profile/[id]',
      params: { id: userId }
    });
  };

  const openChat = (userId: string) => {
    router.push({
      pathname: '/chat/conversation',
      params: { userId }
    });
  };

  const toggleGrowthData = (postId: string) => {
    setShowGrowthData(showGrowthData === postId ? null : postId);
  };

  const filteredPosts = selectedFilter === 'All' 
    ? posts 
    : posts.filter(post => post.category === selectedFilter);

  const renderGrowthCharts = (postId: string) => {
    if (postId !== 'post1') return null;
    
    return (
      <View style={styles.growthContainer}>
        <Text style={styles.growthTitle}>Company Growth Metrics</Text>
        
        <View style={styles.chartContainer}>
          <Text style={styles.chartLabel}>Annual Revenue (in millions)</Text>
          <LineChart
            data={{
              labels: companyGrowthData.labels,
              datasets: [
                {
                  data: companyGrowthData.revenue,
                  color: (opacity = 1) => `rgba(59, 130, 246, ${opacity})`,
                  strokeWidth: 2
                }
              ]
            }}
            width={width - 48}
            height={200}
            chartConfig={chartConfig}
            bezier
            style={styles.chart}
          />
        </View>
        
        <View style={styles.chartContainer}>
          <Text style={styles.chartLabel}>User Growth</Text>
          <BarChart
            data={{
              labels: companyGrowthData.labels,
              datasets: [
                {
                  data: companyGrowthData.users
                }
              ]
            }}
            width={width - 48}
            height={200}
            chartConfig={chartConfig}
            style={styles.chart}
            yAxisLabel=""
            yAxisSuffix=""
          />
        </View>
        
        <View style={styles.metricsGrid}>
          <View style={styles.metricItem}>
            <Text style={styles.metricValue}>12.7M</Text>
            <Text style={styles.metricLabel}>2023 Revenue</Text>
          </View>
          <View style={styles.metricItem}>
            <Text style={styles.metricValue}>9800</Text>
            <Text style={styles.metricLabel}>Active Users</Text>
          </View>
          <View style={styles.metricItem}>
            <Text style={styles.metricValue}>82</Text>
            <Text style={styles.metricLabel}>Employees</Text>
          </View>
          <View style={styles.metricItem}>
            <Text style={styles.metricValue}>200%</Text>
            <Text style={styles.metricLabel}>YoY Growth</Text>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Filter Section */}
      <View style={styles.filterContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false} 
          contentContainerStyle={styles.filterScrollContent}
        >
          {filters.map((filter) => (
            <TouchableOpacity
              key={filter}
              style={[
                styles.filterButton,
                selectedFilter === filter && styles.filterButtonActive
              ]}
              onPress={() => {
                Haptics.selectionAsync();
                setSelectedFilter(filter);
              }}
            >
              <Text style={[
                styles.filterText,
                selectedFilter === filter && styles.filterTextActive
              ]}>
                {filter}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        <TouchableOpacity 
          style={styles.filterIcon}
          onPress={() => Alert.alert('Filter', 'More filter options coming soon!')}
        >
          <Filter size={20} color="#64748B" />
        </TouchableOpacity>
      </View>

      {/* Posts Feed */}
      <FlatList
        data={filteredPosts}
        keyExtractor={(item) => item.id}
        renderItem={({ item: post }) => (
          <Animated.View 
            style={[
              styles.postCard,
              {
                transform: [{
                  scale: post.isLiked ? likeAnimation : 1
                }]
              }
            ]}
          >
            {/* Post Header */}
            <View style={styles.postHeader}>
              <TouchableOpacity 
                style={styles.userInfo}
                onPress={() => openProfile(post.user.id)}
              >
                <Image source={{ uri: post.user.avatar }} style={styles.avatar} />
                <View style={styles.userDetails}>
                  <Text style={styles.userName}>{post.user.name}</Text>
                  <Text style={styles.userTitle}>{post.user.title}</Text>
                  <Text style={styles.timeAgo}>{post.timeAgo} • {post.views} views</Text>
                </View>
              </TouchableOpacity>
              <View style={styles.headerActions}>
                <TouchableOpacity
                  style={[
                    styles.followButton,
                    post.user.isFollowing && styles.followingButton
                  ]}
                  onPress={() => handleFollow(post.user.id)}
                >
                  <Text style={[
                    styles.followText,
                    post.user.isFollowing && styles.followingText
                  ]}>
                    {post.user.isFollowing ? 'Following' : 'Follow'}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.moreButton}
                  onPress={() => setShowOptions(showOptions === post.id ? null : post.id)}
                >
                  <MoreHorizontal size={20} color="#64748B" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Options Menu */}
            {showOptions === post.id && (
              <Animated.View style={styles.optionsMenu}>
                <TouchableOpacity 
                  style={styles.optionItem}
                  onPress={() => handleHidePost(post.id)}
                >
                  <EyeOff size={16} color="#64748B" />
                  <Text style={styles.optionText}>Hide Post</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.optionItem}
                  onPress={() => handleReport(post.id)}
                >
                  <Flag size={16} color="#EF4444" />
                  <Text style={[styles.optionText, { color: '#EF4444' }]}>Report</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  style={styles.optionItem}
                  onPress={() => handleBlock(post.user.id)}
                >
                  <UserX size={16} color="#EF4444" />
                  <Text style={[styles.optionText, { color: '#EF4444' }]}>Block User</Text>
                </TouchableOpacity>
              </Animated.View>
            )}

            {/* Post Content */}
            <Text style={styles.postContent}>{post.content}</Text>
            
            {/* Company Growth Data */}
            {post.id === 'post1' && (
              <TouchableOpacity 
                style={styles.toggleGrowthButton}
                onPress={() => toggleGrowthData(post.id)}
              >
                <Text style={styles.toggleGrowthText}>
                  {showGrowthData === post.id ? 'Hide Company Data' : 'Show Company Growth'}
                </Text>
                {showGrowthData === post.id ? (
                  <ChevronUp size={16} color="#3B82F6" />
                ) : (
                  <ChevronDown size={16} color="#3B82F6" />
                )}
              </TouchableOpacity>
            )}
            
            {showGrowthData === post.id && renderGrowthCharts(post.id)}

            {/* Post Image */}
            {post.image && (
              <TouchableOpacity 
                onPress={() => router.push(`/posts/${post.id}`)}
                activeOpacity={0.9}
              >
                <Image 
                  source={{ uri: post.image }} 
                  style={styles.postImage} 
                  resizeMode="cover"
                />
              </TouchableOpacity>
            )}

            {/* Post Stats */}
            <View style={styles.postStats}>
              <Text style={styles.statText}>{post.likes} likes</Text>
              <Text style={styles.statText}>{post.comments.length} comments</Text>
              <Text style={styles.statText}>{post.shares} shares</Text>
            </View>

            {/* Post Actions */}
            <View style={styles.postActions}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => handleLike(post.id)}
              >
                <Animated.View style={{ transform: [{ scale: likeAnimation }] }}>
                  <Heart 
                    size={20} 
                    color={post.isLiked ? "#EF4444" : "#64748B"}
                    fill={post.isLiked ? "#EF4444" : "none"}
                  />
                </Animated.View>
                <Text style={[
                  styles.actionText,
                  post.isLiked && styles.likedText
                ]}>
                  Like
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => setShowComments(showComments === post.id ? null : post.id)}
              >
                <MessageCircle size={20} color="#64748B" />
                <Text style={styles.actionText}>Comment</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => handleShare(post.id)}
              >
                <Share size={20} color="#64748B" />
                <Text style={styles.actionText}>Share</Text>
              </TouchableOpacity>

              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => openChat(post.user.id)}
              >
                <Mail size={20} color="#3B82F6" />
                <Text style={[styles.actionText, { color: '#3B82F6' }]}>Message</Text>
              </TouchableOpacity>
            </View>

            {/* Comments Section */}
            {showComments === post.id && (
              <Animated.View style={styles.commentsSection}>
                <View style={styles.commentInputContainer}>
                  <Image 
                    source={{ uri: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=50&h=50&fit=crop' }} 
                    style={styles.commentAvatar} 
                  />
                  <TextInput
                    style={styles.commentInput}
                    placeholder="Write a comment..."
                    value={commentText}
                    onChangeText={setCommentText}
                    placeholderTextColor="#94A3B8"
                    multiline
                  />
                  <TouchableOpacity 
                    style={styles.sendButton}
                    onPress={() => handleComment(post.id)}
                    disabled={!commentText.trim()}
                  >
                    <Send size={16} color={commentText.trim() ? "#3B82F6" : "#94A3B8"} />
                  </TouchableOpacity>
                </View>

                {post.comments.length > 0 ? (
                  post.comments.map((comment) => (
                    <View key={comment.id} style={styles.commentItem}>
                      <TouchableOpacity onPress={() => openProfile(comment.user.id)}>
                        <Image source={{ uri: comment.user.avatar }} style={styles.commentAvatar} />
                      </TouchableOpacity>
                      <View style={styles.commentContent}>
                        <View style={styles.commentBubble}>
                          <TouchableOpacity onPress={() => openProfile(comment.user.id)}>
                            <Text style={styles.commentUserName}>{comment.user.name}</Text>
                          </TouchableOpacity>
                          <Text style={styles.commentText}>{comment.text}</Text>
                        </View>
                        <View style={styles.commentActions}>
                          <Text style={styles.commentTime}>{comment.timeAgo}</Text>
                          <TouchableOpacity 
                            style={styles.commentLikeButton}
                            onPress={() => handleCommentLike(post.id, comment.id)}
                          >
                            <Heart 
                              size={14} 
                              color={comment.isLiked ? "#EF4444" : "#64748B"}
                              fill={comment.isLiked ? "#EF4444" : "none"}
                            />
                            <Text style={[
                              styles.commentLikeText,
                              comment.isLiked && { color: '#EF4444' }
                            ]}>
                              {comment.likes > 0 ? comment.likes : ''}
                            </Text>
                          </TouchableOpacity>
                          <TouchableOpacity style={styles.commentActionButton}>
                            <Text style={styles.commentActionText}>Reply</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  ))
                ) : (
                  <Text style={styles.noCommentsText}>No comments yet. Be the first to comment!</Text>
                )}
              </Animated.View>
            )}
          </Animated.View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No posts found for this filter</Text>
          </View>
        }
        contentContainerStyle={styles.feedContent}
        showsVerticalScrollIndicator={false}
      />

      {/* Share Modal */}
      <Modal
        visible={showShareModal !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setShowShareModal(null)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity 
            style={styles.modalBackground}
            activeOpacity={1}
            onPress={() => setShowShareModal(null)}
          />
          <View style={styles.shareModal}>
            <View style={styles.shareHeader}>
              <Text style={styles.shareTitle}>Share Post</Text>
              <TouchableOpacity 
                onPress={() => setShowShareModal(null)}
                hitSlop={{ top: 20, bottom: 20, left: 20, right: 20 }}
              >
                <X size={24} color="#64748B" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.shareOptions}>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>📱</Text>
                </View>
                <Text style={styles.shareOptionText}>Copy Link</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>📧</Text>
                </View>
                <Text style={styles.shareOptionText}>Email</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>💬</Text>
                </View>
                <Text style={styles.shareOptionText}>Message</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>🐦</Text>
                </View>
                <Text style={styles.shareOptionText}>Twitter</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>🔗</Text>
                </View>
                <Text style={styles.shareOptionText}>LinkedIn</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.shareOption}>
                <View style={styles.shareOptionIcon}>
                  <Text style={styles.shareOptionEmoji}>📱</Text>
                </View>
                <Text style={styles.shareOptionText}>WhatsApp</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Report Modal */}
      <Modal
        visible={showReportModal !== null}
        transparent
        animationType="fade"
        onRequestClose={() => setShowReportModal(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.reportModal}>
            <View style={styles.reportHeader}>
              <Text style={styles.reportTitle}>Report Post</Text>
              <TouchableOpacity onPress={() => setShowReportModal(null)}>
                <X size={24} color="#64748B" />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.reportSubtitle}>Why are you reporting this post?</Text>
            
            <View style={styles.reportReasons}>
              <TouchableOpacity 
                style={styles.reportReason}
                onPress={() => setReportReason('Spam')}
              >
                <Text style={styles.reportReasonText}>Spam</Text>
                {reportReason === 'Spam' && <View style={styles.reportReasonSelected} />}
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.reportReason}
                onPress={() => setReportReason('Inappropriate Content')}
              >
                <Text style={styles.reportReasonText}>Inappropriate Content</Text>
                {reportReason === 'Inappropriate Content' && <View style={styles.reportReasonSelected} />}
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.reportReason}
                onPress={() => setReportReason('Harassment')}
              >
                <Text style={styles.reportReasonText}>Harassment</Text>
                {reportReason === 'Harassment' && <View style={styles.reportReasonSelected} />}
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.reportReason}
                onPress={() => setReportReason('False Information')}
              >
                <Text style={styles.reportReasonText}>False Information</Text>
                {reportReason === 'False Information' && <View style={styles.reportReasonSelected} />}
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={styles.reportDetails}
              placeholder="Additional details (optional)"
              placeholderTextColor="#94A3B8"
              multiline
              numberOfLines={4}
            />
            
            <TouchableOpacity
              style={[
                styles.reportSubmit,
                !reportReason && { backgroundColor: '#E2E8F0' }
              ]}
              onPress={submitReport}
              disabled={!reportReason || loading}
            >
              {loading ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.reportSubmitText}>Submit Report</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  filterScrollContent: {
    paddingRight: 16,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
    backgroundColor: '#F1F5F9',
  },
  filterButtonActive: {
    backgroundColor: '#3B82F6',
  },
  filterText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  filterTextActive: {
    color: '#FFFFFF',
  },
  filterIcon: {
    padding: 8,
    marginLeft: 8,
  },
  feedContent: {
    paddingBottom: 20,
  },
  postCard: {
    backgroundColor: '#FFFFFF',
    marginBottom: 12,
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  userTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 2,
  },
  timeAgo: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginTop: 2,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  followButton: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#3B82F6',
    marginRight: 8,
  },
  followingButton: {
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  followText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
  followingText: {
    color: '#64748B',
  },
  moreButton: {
    padding: 4,
  },
  optionsMenu: {
    position: 'absolute',
    top: 60,
    right: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
    zIndex: 1000,
    minWidth: 150,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  optionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    marginLeft: 8,
  },
  postContent: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 24,
    marginBottom: 16,
  },
  toggleGrowthButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingVertical: 8,
  },
  toggleGrowthText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
    marginRight: 8,
  },
  growthContainer: {
    marginBottom: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    padding: 16,
  },
  growthTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 12,
  },
  chartContainer: {
    marginBottom: 20,
  },
  chartLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    marginBottom: 8,
  },
  chart: {
    borderRadius: 12,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  metricItem: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  metricValue: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
  },
  postImage: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  postStats: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginRight: 16,
  },
  postActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    marginLeft: 6,
  },
  likedText: {
    color: '#EF4444',
  },
  commentsSection: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  commentInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  commentAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  commentInput: {
    flex: 1,
    backgroundColor: '#F1F5F9',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
    maxHeight: 100,
  },
  sendButton: {
    padding: 8,
    marginLeft: 8,
  },
  commentItem: {
    flexDirection: 'row',
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  commentContent: {
    flex: 1,
    marginLeft: 8,
  },
  commentBubble: {
    backgroundColor: '#F1F5F9',
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 4,
  },
  commentUserName: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#3B82F6',
    marginBottom: 2,
  },
  commentText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 20,
  },
  commentActions: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 12,
  },
  commentTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginRight: 12,
  },
  commentLikeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 12,
  },
  commentLikeText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 4,
  },
  commentActionButton: {
    paddingHorizontal: 8,
  },
  commentActionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  noCommentsText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
    marginTop: 8,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  shareModal: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingBottom: 34,
  },
  shareHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  shareTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  shareOptions: {
    padding: 20,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  shareOption: {
    width: '30%',
    alignItems: 'center',
    paddingVertical: 16,
    marginBottom: 16,
  },
  shareOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F1F5F9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  shareOptionEmoji: {
    fontSize: 24,
  },
  shareOptionText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    textAlign: 'center',
  },
  reportModal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    margin: 20,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  reportTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  reportSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 20,
  },
  reportReasons: {
    marginBottom: 20,
  },
  reportReason: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  reportReasonText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#334155',
  },
  reportReasonSelected: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#3B82F6',
  },
  reportDetails: {
    backgroundColor: '#F8FAFC',
    borderRadius: 8,
    padding: 16,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    marginBottom: 20,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  reportSubmit: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  reportSubmitText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
});
