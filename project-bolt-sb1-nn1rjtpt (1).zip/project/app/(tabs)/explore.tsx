import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Image,
  TextInput,
  Modal,
  Animated,
  Alert,
} from 'react-native';
import {
  Search,
  MapPin,
  TrendingUp,
  DollarSign,
  Users,
  Star,
  X,
  Bookmark,
  Share,
  Plus,
  File,
} from 'lucide-react-native';
import * as DocumentPicker from 'expo-document-picker';
import * as WebBrowser from 'expo-web-browser';

interface Startup {
  id: string;
  name: string;
  category: string;
  description: string;
  logo: string;
  valuation: string;
  equityOffered: string;
  minInvestment: string;
  location: string;
  founders: number;
  rating: number;
  investors: number;
  raised: string;
  growth: string;
  image: string;
  isBookmarked?: boolean;
  document?: string;
}

const mockStartups: Startup[] = [
  {
    id: '1',
    name: 'EcoTrack',
    category: 'Sustainability',
    description: 'AI-powered carbon footprint tracking for enterprises with real-time analytics and reporting.',
    logo: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    valuation: '$5.2M',
    equityOffered: '15%',
    minInvestment: '$1,000',
    location: 'San Francisco, CA',
    founders: 2,
    rating: 4.8,
    investors: 24,
    raised: '$780K',
    growth: '+45%',
    image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    isBookmarked: false,
    document: 'https://example.com/ecotrack-docs.pdf',
  },
  {
    id: '2',
    name: 'HealthAI',
    category: 'Healthcare',
    description: 'Machine learning diagnostics for early disease detection with 95% accuracy rate.',
    logo: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    valuation: '$12.8M',
    equityOffered: '10%',
    minInvestment: '$2,500',
    location: 'Boston, MA',
    founders: 3,
    rating: 4.9,
    investors: 41,
    raised: '$1.28M',
    growth: '+78%',
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    isBookmarked: true,
    document: 'https://example.com/healthai-docs.pdf',
  },
  {
    id: '3',
    name: 'TechFlow',
    category: 'Productivity',
    description: 'Workflow automation platform for remote teams with seamless integrations.',
    logo: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    valuation: '$8.1M',
    equityOffered: '12%',
    minInvestment: '$1,500',
    location: 'Austin, TX',
    founders: 2,
    rating: 4.7,
    investors: 32,
    raised: '$972K',
    growth: '+62%',
    image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop',
    isBookmarked: false,
    document: 'https://example.com/techflow-docs.pdf',
  },
];

export default function ExploreScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [startups, setStartups] = useState(mockStartups);
  const [showBidModal, setShowBidModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [currentStartupId, setCurrentStartupId] = useState<string | null>(null);
  const [bidAmount, setBidAmount] = useState('');
  const [bidEquity, setBidEquity] = useState('');
  const [bidMessage, setBidMessage] = useState('');
  const [newStartup, setNewStartup] = useState({
    name: '',
    category: '',
    description: '',
    valuation: '',
    equityOffered: '',
    minInvestment: '',
    location: '',
    founders: '',
    rating: '',
    investors: '',
    raised: '',
    growth: '',
  });
  const [document, setDocument] = useState<DocumentPicker.DocumentPickerResult | null>(null);
  
  // Animation values
  const scaleAnimation = useRef(new Animated.Value(1)).current;
  const bookmarkAnimation = useRef(new Animated.Value(1)).current;

  const categories = ['All', 'Healthcare', 'Sustainability', 'Productivity', 'FinTech', 'EdTech'];

  const filteredStartups = startups.filter((startup) => {
    const matchesSearch =
      startup.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      startup.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'All' || startup.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const animatePress = () => {
    Animated.sequence([
      Animated.timing(scaleAnimation, {
        toValue: 0.95,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnimation, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const animateBookmark = () => {
    Animated.sequence([
      Animated.timing(bookmarkAnimation, {
        toValue: 1.3,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(bookmarkAnimation, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handleBid = (startupId: string) => {
    animatePress();
    setCurrentStartupId(startupId);
    setShowBidModal(true);
  };

  const handleBookmark = (startupId: string) => {
    animateBookmark();
    setStartups(startups.map(startup =>
      startup.id === startupId
        ? { ...startup, isBookmarked: !startup.isBookmarked }
        : startup
    ));
  };

  const handleShare = (startup: Startup) => {
    Alert.alert(
      'Share Startup',
      `Share ${startup.name} with others?`,
      [
        { text: 'Copy Link', onPress: () => Alert.alert('Link Copied!') },
        { text: 'Share via Message', onPress: () => Alert.alert('Opening Messages...') },
        { text: 'Cancel', style: 'cancel' },
      ]
    );
  };

  const submitBid = () => {
    if (!bidAmount || !bidEquity) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    Alert.alert(
      'Bid Submitted!',
      `Your bid of $${bidAmount} for ${bidEquity}% equity has been submitted. The founder will review and respond soon.`,
      [{ text: 'OK', onPress: () => {
        setShowBidModal(false);
        setBidAmount('');
        setBidEquity('');
        setBidMessage('');
      }}]
    );
  };

  const viewStartupDetails = (startupId: string) => {
    Alert.alert('Coming Soon', 'Startup detail page will open here');
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: [
          'application/pdf', 
          'application/msword', 
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ],
        copyToCacheDirectory: true,
      });
      
      if (result.type === 'success') {
        setDocument(result);
      } else {
        setDocument(null);
      }
    } catch (err) {
      Alert.alert('Error', 'Failed to pick document');
      console.error(err);
    }
  };

  const removeDocument = () => {
    setDocument(null);
  };

  const handleOpenDocument = async (uri: string) => {
    try {
      await WebBrowser.openBrowserAsync(uri);
    } catch (error) {
      Alert.alert('Error', 'Could not open document. Please make sure you have a PDF viewer installed.');
    }
  };

  const handleAddStartup = () => {
    if (!newStartup.name || !newStartup.category || !newStartup.description) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const newStartupObj: Startup = {
      id: `${Math.random().toString(36).substr(2, 9)}`,
      name: newStartup.name,
      category: newStartup.category,
      description: newStartup.description,
      logo: 'https://placehold.co/100x100',
      valuation: newStartup.valuation || '$0',
      equityOffered: newStartup.equityOffered || '0%',
      minInvestment: newStartup.minInvestment || '$0',
      location: newStartup.location || 'Unknown',
      founders: parseInt(newStartup.founders) || 0,
      rating: parseFloat(newStartup.rating) || 0,
      investors: parseInt(newStartup.investors) || 0,
      raised: newStartup.raised || '$0',
      growth: newStartup.growth || '+0%',
      image: 'https://placehold.co/300x200',
      isBookmarked: false,
      document: document ? document.uri : '',
    };

    setStartups([newStartupObj, ...startups]);
    setShowAddModal(false);
    setNewStartup({
      name: '',
      category: '',
      description: '',
      valuation: '',
      equityOffered: '',
      minInvestment: '',
      location: '',
      founders: '',
      rating: '',
      investors: '',
      raised: '',
      growth: '',
    });
    setDocument(null);
    
    Alert.alert('Success', 'Startup added successfully!');
  };

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Search size={20} color="#64748B" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search startups..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94A3B8"
          />
        </View>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => setShowAddModal(true)}
        >
          <Plus size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* Categories */}
      <View style={styles.categoriesContainer}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {categories.map((category) => (
            <TouchableOpacity
              key={category}
              style={[
                styles.categoryButton,
                selectedCategory === category && styles.categoryButtonActive,
              ]}
              onPress={() => setSelectedCategory(category)}
            >
              <Text
                style={[
                  styles.categoryText,
                  selectedCategory === category && styles.categoryTextActive,
                ]}
              >
                {category}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Startups List */}
      <ScrollView style={styles.startupsList} showsVerticalScrollIndicator={false}>
        {filteredStartups.map((startup) => (
          <Animated.View 
            key={startup.id} 
            style={[
              styles.startupCard,
              { transform: [{ scale: scaleAnimation }] }
            ]}
          >
            <TouchableOpacity onPress={() => viewStartupDetails(startup.id)}>
              <Image source={{ uri: startup.image }} style={styles.startupImage} />
            </TouchableOpacity>

            {/* Bookmark Button */}
            <TouchableOpacity 
              style={styles.bookmarkButton}
              onPress={() => handleBookmark(startup.id)}
            >
              <Animated.View style={{ transform: [{ scale: bookmarkAnimation }] }}>
                <Bookmark 
                  size={20} 
                  color={startup.isBookmarked ? "#F59E0B" : "#64748B"}
                  fill={startup.isBookmarked ? "#F59E0B" : "none"}
                />
              </Animated.View>
            </TouchableOpacity>

            <View style={styles.startupContent}>
              <View style={styles.startupHeader}>
                <View style={styles.startupInfo}>
                  <Text style={styles.startupName}>{startup.name}</Text>
                  <Text style={styles.startupCategory}>{startup.category}</Text>
                </View>
                <View style={styles.ratingContainer}>
                  <Star size={16} color="#FFC107" fill="#FFC107" />
                  <Text style={styles.rating}>{startup.rating}</Text>
                </View>
              </View>

              <Text style={styles.startupDescription}>{startup.description}</Text>

              <View style={styles.locationContainer}>
                <MapPin size={14} color="#64748B" />
                <Text style={styles.location}>{startup.location}</Text>
              </View>

              <View style={styles.metricsContainer}>
                <View style={styles.metric}>
                  <Text style={styles.metricLabel}>Valuation</Text>
                  <Text style={styles.metricValue}>{startup.valuation}</Text>
                </View>
                <View style={styles.metric}>
                  <Text style={styles.metricLabel}>Equity</Text>
                  <Text style={styles.metricValue}>{startup.equityOffered}</Text>
                </View>
                <View style={styles.metric}>
                  <Text style={styles.metricLabel}>Min. Investment</Text>
                  <Text style={styles.metricValue}>{startup.minInvestment}</Text>
                </View>
              </View>

              <View style={styles.statsContainer}>
                <View style={styles.stat}>
                  <Users size={16} color="#64748B" />
                  <Text style={styles.statText}>{startup.investors} investors</Text>
                </View>
                <View style={styles.stat}>
                  <DollarSign size={16} color="#64748B" />
                  <Text style={styles.statText}>{startup.raised} raised</Text>
                </View>
                <View style={styles.stat}>
                  <TrendingUp size={16} color="#10B981" />
                  <Text style={[styles.statText, styles.growthText]}>{startup.growth}</Text>
                </View>
              </View>

              {/* Action Buttons */}
              <View style={styles.actionButtons}>
                <TouchableOpacity
                  style={styles.bidButton}
                  onPress={() => handleBid(startup.id)}
                >
                  <Text style={styles.bidButtonText}>Make Bid</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={styles.shareButton}
                  onPress={() => handleShare(startup)}
                >
                  <Share size={16} color="#64748B" />
                </TouchableOpacity>
              </View>

              {/* Document Link */}
              {startup.document && (
                <TouchableOpacity 
                  style={styles.documentLinkContainer}
                  onPress={() => handleOpenDocument(startup.document as string)}
                >
                  <File size={16} color="#3B82F6" />
                  <Text style={styles.documentLink}>View Legal Documentation</Text>
                </TouchableOpacity>
              )}
            </View>
          </Animated.View>
        ))}
      </ScrollView>

      {/* Bid Modal */}
      <Modal visible={showBidModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Place Your Bid</Text>
              <TouchableOpacity onPress={() => setShowBidModal(false)}>
                <X size={24} color="#64748B" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Bid Amount ($) *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="Enter amount"
                  value={bidAmount}
                  onChangeText={setBidAmount}
                  keyboardType="numeric"
                  placeholderTextColor="#94A3B8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Equity Percentage (%) *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="Enter percentage"
                  value={bidEquity}
                  onChangeText={setBidEquity}
                  keyboardType="numeric"
                  placeholderTextColor="#94A3B8"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Message to Founder</Text>
                <TextInput
                  style={[styles.modalInput, styles.messageInput]}
                  placeholder="Tell them why you want to invest..."
                  value={bidMessage}
                  onChangeText={setBidMessage}
                  multiline
                  numberOfLines={4}
                  placeholderTextColor="#94A3B8"
                />
              </View>

              <TouchableOpacity style={styles.submitButton} onPress={submitBid}>
                <Text style={styles.submitButtonText}>Submit Bid</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Add Startup Modal */}
      <Modal visible={showAddModal} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add New Startup</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <X size={24} color="#64748B" />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.addModalContent}>
              {[
                { label: 'Startup Name *', key: 'name' },
                { label: 'Category *', key: 'category' },
                { label: 'Description *', key: 'description' },
                { label: 'Valuation', key: 'valuation' },
                { label: 'Equity Offered', key: 'equityOffered' },
                { label: 'Min. Investment', key: 'minInvestment' },
                { label: 'Location', key: 'location' },
                { label: 'Founders Count', key: 'founders' },
                { label: 'Rating (1-5)', key: 'rating' },
                { label: 'Investors Count', key: 'investors' },
                { label: 'Amount Raised', key: 'raised' },
                { label: 'Growth (%)', key: 'growth' },
              ].map((field) => (
                <View style={styles.inputGroup} key={field.key}>
                  <Text style={styles.inputLabel}>{field.label}</Text>
                  <TextInput
                    style={styles.modalInput}
                    placeholder={`Enter ${field.key}`}
                    value={newStartup[field.key]}
                    onChangeText={(text) => setNewStartup({ ...newStartup, [field.key]: text })}
                    placeholderTextColor="#94A3B8"
                  />
                </View>
              ))}

              {/* Document Upload Section */}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Legal Documentation</Text>
                
                {document ? (
                  <View style={styles.documentContainer}>
                    <View style={styles.documentInfo}>
                      <File size={20} color="#3B82F6" />
                      <Text style={styles.documentName} numberOfLines={1}>
                        {document.name}
                      </Text>
                    </View>
                    <TouchableOpacity onPress={removeDocument}>
                      <X size={20} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                ) : (
                  <TouchableOpacity 
                    style={styles.uploadButton}
                    onPress={pickDocument}
                  >
                    <Text style={styles.uploadButtonText}>Upload Document</Text>
                  </TouchableOpacity>
                )}
                
                <Text style={styles.documentHint}>
                  Upload legal documents, pitch decks, or financial statements (PDF, DOC, DOCX)
                </Text>
              </View>

              <TouchableOpacity 
                style={styles.submitButton} 
                onPress={handleAddStartup}
              >
                <Text style={styles.submitButtonText}>Add Startup</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  searchContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flex: 1,
  },
  addButton: {
    backgroundColor: '#10B981',
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
  },
  categoriesContainer: {
    paddingVertical: 12,
    paddingLeft: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 8,
    borderRadius: 20,
    backgroundColor: '#F1F5F9',
  },
  categoryButtonActive: {
    backgroundColor: '#3B82F6',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  categoryTextActive: {
    color: '#FFFFFF',
  },
  startupsList: {
    flex: 1,
    padding: 16,
  },
  startupCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
    position: 'relative',
  },
  startupImage: {
    width: '100%',
    height: 160,
  },
  bookmarkButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 20,
    padding: 8,
    zIndex: 1,
  },
  startupContent: {
    padding: 20,
  },
  startupHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  startupInfo: {
    flex: 1,
  },
  startupName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  startupCategory: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
    marginTop: 2,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginLeft: 4,
  },
  startupDescription: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 24,
    marginBottom: 12,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  location: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 6,
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#E2E8F0',
  },
  metric: {
    alignItems: 'center',
  },
  metricLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    marginBottom: 4,
  },
  metricValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  stat: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 6,
  },
  growthText: {
    color: '#10B981',
    fontFamily: 'Inter-SemiBold',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bidButton: {
    flex: 1,
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    marginRight: 12,
  },
  bidButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  shareButton: {
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    width: '90%',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  modalTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  modalContent: {
    padding: 20,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#374151',
    marginBottom: 8,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
    backgroundColor: '#FAFAFA',
  },
  messageInput: {
    height: 80,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  addModalContent: {
    padding: 20,
    maxHeight: '80%',
  },
  // Document upload styles
  uploadButton: {
    borderWidth: 1,
    borderColor: '#3B82F6',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    backgroundColor: '#EFF6FF',
    borderStyle: 'dashed',
  },
  uploadButtonText: {
    color: '#3B82F6',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  documentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  documentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  documentName: {
    marginLeft: 8,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    flex: 1,
  },
  documentHint: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginTop: 6,
  },
  // Document link styles
  documentLinkContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  documentLink: {
    marginLeft: 8,
    color: '#3B82F6',
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
});