import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, Switch, Alert } from 'react-native';
import { router } from 'expo-router';
import { Settings, User, Lock, Eye, EyeOff, UserPlus, LogOut, CircleHelp as HelpCircle, Shield, Users, MessageCircle, CreditCard as Edit3 } from 'lucide-react-native';

interface Account {
  id: string;
  name: string;
  email: string;
  avatar: string;
  isActive: boolean;
}

const mockAccounts: Account[] = [
  {
    id: '1',
    name: 'John Investor',
    email: 'john@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    isActive: true,
  },
  {
    id: '2',
    name: 'Sarah Venture',
    email: 'sarah@venture.com',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    isActive: false,
  },
];

export default function ProfileScreen() {
  const [accounts, setAccounts] = useState(mockAccounts);
  const [isPrivate, setIsPrivate] = useState(false);
  const [showAccountSwitcher, setShowAccountSwitcher] = useState(false);

  const activeAccount = accounts.find(acc => acc.isActive);

  const handleAccountSwitch = (accountId: string) => {
    setAccounts(accounts.map(acc => ({
      ...acc,
      isActive: acc.id === accountId
    })));
    setShowAccountSwitcher(false);
  };

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Sign Out', 
          style: 'destructive',
          onPress: () => router.replace('/auth')
        }
      ]
    );
  };

  const MenuSection = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <View style={styles.menuSection}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );

  const MenuItem = ({ 
    icon, 
    title, 
    subtitle, 
    onPress, 
    rightElement 
  }: { 
    icon: React.ReactNode; 
    title: string; 
    subtitle?: string; 
    onPress?: () => void;
    rightElement?: React.ReactNode;
  }) => (
    <TouchableOpacity style={styles.menuItem} onPress={onPress}>
      <View style={styles.menuItemLeft}>
        <View style={styles.menuItemIcon}>{icon}</View>
        <View style={styles.menuItemText}>
          <Text style={styles.menuItemTitle}>{title}</Text>
          {subtitle && <Text style={styles.menuItemSubtitle}>{subtitle}</Text>}
        </View>
      </View>
      {rightElement}
    </TouchableOpacity>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Profile Header */}
      <View style={styles.profileHeader}>
        <View style={styles.profileInfo}>
          <Image source={{ uri: activeAccount?.avatar }} style={styles.profileAvatar} />
          <View style={styles.profileDetails}>
            <Text style={styles.profileName}>{activeAccount?.name}</Text>
            <Text style={styles.profileEmail}>{activeAccount?.email}</Text>
          </View>
          <TouchableOpacity style={styles.editButton}>
            <Edit3 size={20} color="#3B82F6" />
          </TouchableOpacity>
        </View>

        {/* Profile Stats */}
        <View style={styles.profileStats}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>12</Text>
            <Text style={styles.statLabel}>Posts</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>1.2K</Text>
            <Text style={styles.statLabel}>Followers</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>324</Text>
            <Text style={styles.statLabel}>Following</Text>
          </View>
        </View>
      </View>

      {/* Account Management */}
      <MenuSection title="Account Management">
        <MenuItem
          icon={<UserPlus size={20} color="#64748B" />}
          title="Switch Account"
          subtitle={`Currently: ${activeAccount?.name}`}
          onPress={() => setShowAccountSwitcher(!showAccountSwitcher)}
        />
        
        {showAccountSwitcher && (
          <View style={styles.accountSwitcher}>
            {accounts.map((account) => (
              <TouchableOpacity
                key={account.id}
                style={[
                  styles.accountItem,
                  account.isActive && styles.activeAccountItem
                ]}
                onPress={() => handleAccountSwitch(account.id)}
              >
                <Image source={{ uri: account.avatar }} style={styles.accountAvatar} />
                <View style={styles.accountDetails}>
                  <Text style={styles.accountName}>{account.name}</Text>
                  <Text style={styles.accountEmail}>{account.email}</Text>
                </View>
                {account.isActive && (
                  <View style={styles.activeIndicator} />
                )}
              </TouchableOpacity>
            ))}
            <TouchableOpacity style={styles.addAccountButton}>
              <UserPlus size={20} color="#3B82F6" />
              <Text style={styles.addAccountText}>Add Account</Text>
            </TouchableOpacity>
          </View>
        )}

        <MenuItem
          icon={<User size={20} color="#64748B" />}
          title="Edit Profile"
          subtitle="Update your personal information"
        />

        <MenuItem
          icon={<Lock size={20} color="#64748B" />}
          title="Change Password"
          subtitle="Update your password"
        />
      </MenuSection>

      {/* Privacy & Security */}
      <MenuSection title="Privacy & Security">
        <MenuItem
          icon={isPrivate ? <EyeOff size={20} color="#64748B" /> : <Eye size={20} color="#64748B" />}
          title="Private Account"
          subtitle="Control who can see your profile"
          rightElement={
            <Switch
              value={isPrivate}
              onValueChange={setIsPrivate}
              trackColor={{ false: '#E2E8F0', true: '#3B82F6' }}
              thumbColor={isPrivate ? '#FFFFFF' : '#94A3B8'}
            />
          }
        />

        <MenuItem
          icon={<Shield size={20} color="#64748B" />}
          title="Blocked Users"
          subtitle="Manage blocked accounts"
        />

        <MenuItem
          icon={<Users size={20} color="#64748B" />}
          title="Who Can Contact Me"
          subtitle="Control message permissions"
        />
      </MenuSection>

      {/* Support */}
      <MenuSection title="Support & Help">
        <MenuItem
          icon={<MessageCircle size={20} color="#64748B" />}
          title="Contact Support"
          subtitle="Send a message to our team"
        />

        <MenuItem
          icon={<HelpCircle size={20} color="#64748B" />}
          title="Help Center"
          subtitle="FAQs and guides"
        />
      </MenuSection>

      {/* Sign Out */}
      <View style={styles.signOutSection}>
        <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
          <LogOut size={20} color="#EF4444" />
          <Text style={styles.signOutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.bottomSpacing} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  profileHeader: {
    backgroundColor: '#FFFFFF',
    padding: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  profileDetails: {
    flex: 1,
  },
  profileName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  profileEmail: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 4,
  },
  editButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
  },
  profileStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 4,
  },
  menuSection: {
    backgroundColor: '#FFFFFF',
    marginTop: 12,
    paddingVertical: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    paddingHorizontal: 24,
    paddingVertical: 12,
    backgroundColor: '#F8FAFC',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuItemIcon: {
    marginRight: 16,
  },
  menuItemText: {
    flex: 1,
  },
  menuItemTitle: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1E293B',
  },
  menuItemSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 2,
  },
  accountSwitcher: {
    backgroundColor: '#F8FAFC',
    marginHorizontal: 24,
    borderRadius: 12,
    overflow: 'hidden',
  },
  accountItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  activeAccountItem: {
    backgroundColor: '#EBF4FF',
  },
  accountAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  accountDetails: {
    flex: 1,
  },
  accountName: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#1E293B',
  },
  accountEmail: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 2,
  },
  activeIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#3B82F6',
  },
  addAccountButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  addAccountText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
    marginLeft: 8,
  },
  signOutSection: {
    backgroundColor: '#FFFFFF',
    marginTop: 12,
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  signOutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  signOutText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#EF4444',
    marginLeft: 8,
  },
  bottomSpacing: {
    height: 32,
  },
});