import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Image,
  TouchableOpacity,
  Linking,
} from 'react-native';
import {
  ArrowLeft,
  BarChart2,
  DollarSign,
  PieChart as PieChartIcon,
  Clock,
  Share2,
  Globe,
  Mail,
  Twitter,
  Linkedin,
  MapPin,
  Users,
  Calendar,
  ChevronRight,
} from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LineChart, PieChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

// Mock data - in a real app, you'd fetch this based on the ID
const investmentData = {
  id: '1',
  startup: { 
    name: 'EcoTrack', 
    logo: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg', 
    category: 'Sustainability',
    stage: 'Series A',
    founder: 'Sarah Chen',
    description: 'AI-powered carbon footprint analytics for businesses helping enterprises measure, reduce, and offset their environmental impact through advanced machine learning algorithms.',
    website: 'https://ecotrack.example.com',
    email: 'contact@ecotrack.example.com',
    twitter: 'ecotrack_ai',
    linkedin: 'company/ecotrack',
    location: 'San Francisco, CA',
    teamSize: 42,
    founded: '2021',
  },
  investedAmount: 5000,
  equityPercentage: 2.5,
  currentValue: 6750,
  growth: 35,
  investmentDate: '2024-01-15',
  lastUpdate: '2024-06-29',
  performanceData: [5000, 5200, 5800, 6200, 6750],
  performanceLabels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
  keyMetrics: [
    { label: 'MRR Growth', value: '28%', trend: 'up' },
    { label: 'Customer Churn', value: '4.2%', trend: 'down' },
    { label: 'ARR', value: '$2.8M', trend: 'up' },
    { label: 'CAC', value: '$1,200', trend: 'down' },
  ],
  recentUpdates: [
    { date: '2024-06-15', title: 'Closed partnership with Microsoft', summary: 'Integration with Azure sustainability tools' },
    { date: '2024-05-22', title: 'Featured in TechCrunch', summary: 'Highlighted as a top sustainability startup to watch' },
    { date: '2024-04-10', title: 'Product update', summary: 'Launched new carbon offset marketplace' },
  ],
};

const chartConfig = {
  backgroundColor: "#ffffff",
  backgroundGradientFrom: "#ffffff",
  backgroundGradientTo: "#ffffff",
  decimalPlaces: 0,
  color: (opacity = 1) => `rgba(16, 185, 129, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(30, 41, 59, ${opacity})`,
  style: {
    borderRadius: 16
  },
  propsForDots: {
    r: "4",
    strokeWidth: "2",
    stroke: "#10B981"
  }
};

export default function InvestmentDetailScreen() {
  const { id } = useLocalSearchParams();
  // In a real app, you would fetch the investment data based on the ID
  const investment = investmentData;

  const handleBack = () => {
    router.back();
  };

  const handleShare = () => {
    // Implement share functionality
  };

  const openWebsite = () => {
    Linking.openURL(investment.startup.website);
  };

  const openTwitter = () => {
    Linking.openURL(`https://twitter.com/${investment.startup.twitter}`);
  };

  const openLinkedIn = () => {
    Linking.openURL(`https://linkedin.com/${investment.startup.linkedin}`);
  };

  const sendEmail = () => {
    Linking.openURL(`mailto:${investment.startup.email}`);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <ArrowLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Investment Details</Text>
        <TouchableOpacity onPress={handleShare} style={styles.shareButton}>
          <Share2 size={24} color="#3B82F6" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Startup Overview */}
        <View style={styles.overviewCard}>
          <View style={styles.overviewHeader}>
            <Image source={{ uri: investment.startup.logo }} style={styles.companyLogo} />
            <View style={styles.overviewText}>
              <Text style={styles.companyName}>{investment.startup.name}</Text>
              <Text style={styles.companyCategory}>{investment.startup.category}</Text>
            </View>
          </View>
          <Text style={styles.companyDescription}>{investment.startup.description}</Text>
          
          <View style={styles.socialLinks}>
            <TouchableOpacity onPress={openWebsite} style={styles.socialButton}>
              <Globe size={20} color="#3B82F6" />
            </TouchableOpacity>
            <TouchableOpacity onPress={sendEmail} style={styles.socialButton}>
              <Mail size={20} color="#3B82F6" />
            </TouchableOpacity>
            <TouchableOpacity onPress={openTwitter} style={styles.socialButton}>
              <Twitter size={20} color="#3B82F6" />
            </TouchableOpacity>
            <TouchableOpacity onPress={openLinkedIn} style={styles.socialButton}>
              <Linkedin size={20} color="#3B82F6" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Performance Chart */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <BarChart2 size={20} color="#3B82F6" />
            <Text style={styles.cardTitle}>Performance</Text>
          </View>
          <LineChart
            data={{
              labels: investment.performanceLabels,
              datasets: [
                {
                  data: investment.performanceData,
                  color: (opacity = 1) => `rgba(16, 185, 129, ${opacity})`,
                  strokeWidth: 2
                }
              ]
            }}
            width={width - 48}
            height={220}
            chartConfig={chartConfig}
            bezier
            withDots={true}
            withShadow={false}
            withInnerLines={false}
            withOuterLines={false}
            style={styles.chart}
          />
        </View>

        {/* Investment Details */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <DollarSign size={20} color="#3B82F6" />
            <Text style={styles.cardTitle}>Investment Details</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Invested Amount</Text>
            <Text style={styles.detailValue}>${investment.investedAmount.toLocaleString()}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Current Value</Text>
            <Text style={[styles.detailValue, styles.positiveValue]}>${investment.currentValue.toLocaleString()}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Equity Percentage</Text>
            <Text style={styles.detailValue}>{investment.equityPercentage}%</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Growth</Text>
            <View style={styles.growthBadge}>
              {investment.growth >= 0 ? (
                <>
                  <Text style={[styles.detailValue, styles.positiveValue]}>+{investment.growth}%</Text>
                </>
              ) : (
                <>
                  <Text style={[styles.detailValue, styles.negativeValue]}>{investment.growth}%</Text>
                </>
              )}
            </View>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Investment Date</Text>
            <Text style={styles.detailValue}>{investment.investmentDate}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Last Valuation</Text>
            <Text style={styles.detailValue}>{investment.lastUpdate}</Text>
          </View>
        </View>

        {/* Company Information */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <PieChartIcon size={20} color="#3B82F6" />
            <Text style={styles.cardTitle}>Company Information</Text>
          </View>
          <View style={styles.infoItem}>
            <MapPin size={16} color="#64748B" />
            <Text style={styles.infoText}>{investment.startup.location}</Text>
          </View>
          <View style={styles.infoItem}>
            <Users size={16} color="#64748B" />
            <Text style={styles.infoText}>{investment.startup.teamSize} employees</Text>
          </View>
          <View style={styles.infoItem}>
            <Calendar size={16} color="#64748B" />
            <Text style={styles.infoText}>Founded in {investment.startup.founded}</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={[styles.infoText, styles.infoLabel]}>Stage:</Text>
            <Text style={styles.infoText}>{investment.startup.stage}</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={[styles.infoText, styles.infoLabel]}>Founder:</Text>
            <Text style={styles.infoText}>{investment.startup.founder}</Text>
          </View>
        </View>

        {/* Key Metrics */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <BarChart2 size={20} color="#3B82F6" />
            <Text style={styles.cardTitle}>Key Metrics</Text>
          </View>
          <View style={styles.metricsContainer}>
            {investment.keyMetrics.map((metric, index) => (
              <View key={index} style={styles.metricItem}>
                <Text style={styles.metricLabel}>{metric.label}</Text>
                <Text style={[
                  styles.metricValue,
                  metric.trend === 'up' ? styles.positiveValue : styles.negativeValue
                ]}>
                  {metric.value}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent Updates */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Clock size={20} color="#3B82F6" />
            <Text style={styles.cardTitle}>Recent Updates</Text>
          </View>
          {investment.recentUpdates.map((update, index) => (
            <View key={index} style={styles.updateItem}>
              <View style={styles.updateHeader}>
                <Text style={styles.updateDate}>{update.date}</Text>
                <ChevronRight size={16} color="#64748B" />
              </View>
              <Text style={styles.updateTitle}>{update.title}</Text>
              <Text style={styles.updateSummary}>{update.summary}</Text>
              {index < investment.recentUpdates.length - 1 && (
                <View style={styles.divider} />
              )}
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 48,
    backgroundColor: '#FFFFFF',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  shareButton: {
    padding: 8,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 16,
    paddingBottom: 24,
  },
  overviewCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  overviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  companyLogo: {
    width: 64,
    height: 64,
    borderRadius: 16,
    marginRight: 16,
  },
  overviewText: {
    flex: 1,
  },
  companyName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 4,
  },
  companyCategory: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  companyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#475569',
    lineHeight: 22,
    marginBottom: 16,
  },
  socialLinks: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 8,
  },
  socialButton: {
    padding: 12,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginLeft: 8,
  },
  chart: {
    borderRadius: 12,
    marginLeft: -16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  positiveValue: {
    color: '#10B981',
  },
  negativeValue: {
    color: '#EF4444',
  },
  growthBadge: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  infoText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#475569',
    marginLeft: 12,
  },
  infoLabel: {
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    minWidth: 80,
  },
  metricsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  metricItem: {
    width: '48%',
    paddingVertical: 12,
  },
  metricLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 4,
  },
  metricValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  updateItem: {
    paddingVertical: 12,
  },
  updateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  updateDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  updateTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 4,
  },
  updateSummary: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#475569',
    lineHeight: 20,
  },
  divider: {
    height: 1,
    backgroundColor: '#F1F5F9',
    marginVertical: 12,
  },
});