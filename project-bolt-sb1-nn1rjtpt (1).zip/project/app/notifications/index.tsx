import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { router } from 'expo-router';
import { ArrowLeft, Heart, MessageCircle, TrendingUp, UserPlus, DollarSign, Bell } from 'lucide-react-native';

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'investment' | 'bid_update' | 'message';
  user: {
    name: string;
    avatar: string;
  };
  content: string;
  time: string;
  isRead: boolean;
  actionData?: {
    postId?: string;
    startupName?: string;
    amount?: string;
  };
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'investment',
    user: {
      name: 'Sarah Chen',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'accepted your bid for EcoTrack! Your investment of $5,000 has been confirmed.',
    time: '5 minutes ago',
    isRead: false,
    actionData: {
      startupName: 'EcoTrack',
      amount: '$5,000',
    },
  },
  {
    id: '2',
    type: 'like',
    user: {
      name: 'David Rodriguez',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'liked your post about sustainable investing strategies.',
    time: '1 hour ago',
    isRead: false,
  },
  {
    id: '3',
    type: 'follow',
    user: {
      name: 'Emily Zhang',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'started following you.',
    time: '3 hours ago',
    isRead: false,
  },
  {
    id: '4',
    type: 'comment',
    user: {
      name: 'Michael Kim',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'commented on your investment analysis: "Great insights! Have you considered the scalability factors?"',
    time: '6 hours ago',
    isRead: true,
  },
  {
    id: '5',
    type: 'bid_update',
    user: {
      name: 'TechFlow Team',
      avatar: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'Your investment in TechFlow has grown by 12% this month!',
    time: '1 day ago',
    isRead: true,
    actionData: {
      startupName: 'TechFlow',
    },
  },
  {
    id: '6',
    type: 'message',
    user: {
      name: 'Alex Wilson',
      avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    },
    content: 'sent you a message about the Series A funding round.',
    time: '2 days ago',
    isRead: true,
  },
];

const getNotificationIcon = (type: string) => {
  switch (type) {
    case 'like':
      return <Heart size={20} color="#EF4444" fill="#EF4444" />;
    case 'comment':
      return <MessageCircle size={20} color="#3B82F6" />;
    case 'follow':
      return <UserPlus size={20} color="#10B981" />;
    case 'investment':
    case 'bid_update':
      return <TrendingUp size={20} color="#F59E0B" />;
    case 'message':
      return <MessageCircle size={20} color="#8B5CF6" />;
    default:
      return <Bell size={20} color="#64748B" />;
  }
};

export default function NotificationsScreen() {
  const [notifications, setNotifications] = useState(mockNotifications);

  const markAsRead = (notificationId: string) => {
    setNotifications(notifications.map(notif =>
      notif.id === notificationId ? { ...notif, isRead: true } : notif
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, isRead: true })));
  };

  const unreadCount = notifications.filter(notif => !notif.isRead).length;

  const handleNotificationPress = (notification: Notification) => {
    markAsRead(notification.id);
    
    // Navigate based on notification type
    switch (notification.type) {
      case 'investment':
      case 'bid_update':
        router.push('/(tabs)/portfolio');
        break;
      case 'message':
        router.push('/chat');
        break;
      case 'like':
      case 'comment':
      case 'follow':
        router.push('/(tabs)');
        break;
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Notifications</Text>
        {unreadCount > 0 && (
          <TouchableOpacity onPress={markAllAsRead} style={styles.markAllButton}>
            <Text style={styles.markAllText}>Mark all read</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Unread Count */}
      {unreadCount > 0 && (
        <View style={styles.unreadContainer}>
          <Text style={styles.unreadText}>
            {unreadCount} unread notification{unreadCount > 1 ? 's' : ''}
          </Text>
        </View>
      )}

      {/* Notifications List */}
      <ScrollView style={styles.notificationsList} showsVerticalScrollIndicator={false}>
        {notifications.map((notification) => (
          <TouchableOpacity
            key={notification.id}
            style={[
              styles.notificationItem,
              !notification.isRead && styles.unreadNotification
            ]}
            onPress={() => handleNotificationPress(notification)}
          >
            <View style={styles.notificationContent}>
              <View style={styles.avatarContainer}>
                <Image source={{ uri: notification.user.avatar }} style={styles.avatar} />
                <View style={styles.iconContainer}>
                  {getNotificationIcon(notification.type)}
                </View>
              </View>
              
              <View style={styles.textContent}>
                <Text style={styles.notificationText}>
                  <Text style={styles.userName}>{notification.user.name}</Text>
                  {' '}
                  {notification.content}
                </Text>
                <Text style={styles.notificationTime}>{notification.time}</Text>
              </View>
              
              {!notification.isRead && (
                <View style={styles.unreadDot} />
              )}
            </View>
          </TouchableOpacity>
        ))}
        
        {notifications.length === 0 && (
          <View style={styles.emptyState}>
            <Bell size={48} color="#94A3B8" />
            <Text style={styles.emptyTitle}>No notifications yet</Text>
            <Text style={styles.emptySubtitle}>
              You'll see notifications about likes, comments, and investment updates here.
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  markAllButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  markAllText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
  },
  unreadContainer: {
    backgroundColor: '#EBF4FF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  unreadText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
  },
  notificationsList: {
    flex: 1,
  },
  notificationItem: {
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  unreadNotification: {
    backgroundColor: '#FEFEFE',
    borderLeftWidth: 4,
    borderLeftColor: '#3B82F6',
  },
  notificationContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 20,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 16,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
  },
  iconContainer: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  textContent: {
    flex: 1,
  },
  notificationText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#334155',
    lineHeight: 24,
    marginBottom: 4,
  },
  userName: {
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  notificationTime: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#3B82F6',
    marginLeft: 12,
    marginTop: 8,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 24,
  },
});