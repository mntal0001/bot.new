import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, FlatList, Image } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { Phone, Video, MoreHorizontal, ArrowLeft, Send } from 'lucide-react-native';

const mockChats = [
  {
    id: '1',
    user: {
      name: 'Sarah Chen',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      title: 'Co-founder at EcoTrack',
      isOnline: true,
    },
    lastMessage: {
      text: 'Thanks for your interest in EcoTrack! I\'d love to discuss the investment opportunity.',
      time: '9:42 AM',
      isRead: false,
      sender: 'them',
    },
    unreadCount: 2,
  },
  // 🔁 Add other chat objects here just like above
];

export default function ChatConversation() {
  const { id } = useLocalSearchParams();
  const chatId = Array.isArray(id) ? id[0] : id;
  const chat = mockChats.find(c => c.id === chatId);

  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');

  useEffect(() => {
    if (chat) {
      setMessages([
        { sender: 'them', text: chat.lastMessage.text },
        { sender: 'me', text: 'Sure, let me get back to you.' },
      ]);
    }
  }, [chat]);

  const sendMessage = () => {
    if (text.trim()) {
      setMessages([...messages, { sender: 'me', text }]);
      setText('');
    }
  };

  if (!chat) return <Text style={{ padding: 20 }}>Chat not found</Text>;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ArrowLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Image source={{ uri: chat.user.avatar }} style={styles.avatar} />
          <View>
            <Text style={styles.name}>{chat.user.name}</Text>
            <Text style={styles.title}>{chat.user.title}</Text>
          </View>
        </View>
        <View style={styles.actions}>
          <TouchableOpacity><Phone size={22} color="#3B82F6" /></TouchableOpacity>
          <TouchableOpacity><Video size={22} color="#3B82F6" style={{ marginHorizontal: 10 }} /></TouchableOpacity>
          <TouchableOpacity><MoreHorizontal size={22} color="#3B82F6" /></TouchableOpacity>
        </View>
      </View>

      {/* Chat Messages */}
      <FlatList
        data={messages}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={[styles.message, item.sender === 'me' ? styles.myMessage : styles.theirMessage]}>
            <Text style={styles.messageText}>{item.text}</Text>
          </View>
        )}
        style={styles.messageList}
      />

      {/* Message Input */}
      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          value={text}
          onChangeText={setText}
        />
        <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
          <Send size={20} color="#FFF" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 16, backgroundColor: '#FFF', borderBottomColor: '#E2E8F0', borderBottomWidth: 1
  },
  headerInfo: { flexDirection: 'row', alignItems: 'center', flex: 1, marginLeft: 10 },
  avatar: { width: 40, height: 40, borderRadius: 20, marginRight: 10 },
  name: { fontSize: 16, fontWeight: '600', color: '#1E293B' },
  title: { fontSize: 12, color: '#64748B' },
  actions: { flexDirection: 'row', alignItems: 'center' },
  messageList: { flex: 1, padding: 16 },
  message: {
    padding: 12, marginVertical: 6, borderRadius: 16, maxWidth: '80%',
  },
  myMessage: {
    backgroundColor: '#3B82F6', alignSelf: 'flex-end',
  },
  theirMessage: {
    backgroundColor: '#E5E7EB', alignSelf: 'flex-start',
  },
  messageText: { color: '#FFF', fontSize: 14 },
  inputBar: {
    flexDirection: 'row', padding: 12, backgroundColor: '#FFF', borderTopWidth: 1, borderTopColor: '#E2E8F0'
  },
  input: {
    flex: 1, backgroundColor: '#F1F5F9', borderRadius: 20, paddingHorizontal: 16
  },
  sendButton: {
    backgroundColor: '#3B82F6', borderRadius: 20, padding: 10, marginLeft: 8
  }
});
