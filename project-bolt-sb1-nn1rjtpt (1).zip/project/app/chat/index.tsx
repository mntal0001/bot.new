import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image, TextInput } from 'react-native';
import { router } from 'expo-router';
import { Search, MoveHorizontal as MoreHorizontal, ArrowLeft, Plus } from 'lucide-react-native';

interface Chat {
  id: string;
  user: {
    name: string;
    avatar: string;
    title: string;
    isOnline: boolean;
  };
  lastMessage: {
    text: string;
    time: string;
    isRead: boolean;
    sender: 'me' | 'them';
  };
  unreadCount: number;
}

const mockChats: Chat[] = [
  {
    id: '1',
    user: {
      name: 'Sarah Chen',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      title: 'Co-founder at EcoTrack',
      isOnline: true,
    },
    lastMessage: {
      text: 'Thanks for your interest in EcoTrack! I\'d love to discuss the investment opportunity.',
      time: '9:42 AM',
      isRead: false,
      sender: 'them',
    },
    unreadCount: 2,
  },
  {
    id: '2',
    user: {
      name: 'David Rodriguez',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      title: 'Founder at HealthAI',
      isOnline: false,
    },
    lastMessage: {
      text: 'Let\'s schedule a call to discuss the partnership details.',
      time: '8:15 AM',
      isRead: false,
      sender: 'them',
    },
    unreadCount: 1,
  },
  {
    id: '3',
    user: {
      name: 'Emily Zhang',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      title: 'CEO at TechFlow',
      isOnline: true,
    },
    lastMessage: {
      text: 'Your pitch deck looks promising. When can we talk?',
      time: 'Yesterday',
      isRead: true,
      sender: 'me',
    },
    unreadCount: 0,
  },
  {
    id: '4',
    user: {
      name: 'Michael Kim',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      title: 'Investor Relations',
      isOnline: false,
    },
    lastMessage: {
      text: 'The quarterly report has been updated with new metrics.',
      time: 'Tuesday',
      isRead: true,
      sender: 'them',
    },
    unreadCount: 0,
  },
];

export default function ChatScreen() {
  const [chats, setChats] = useState(mockChats);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChats = chats.filter(chat =>
    chat.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage.text.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleChatPress = (chatId: string) => {
    // Navigate to individual chat screen
    router.push(`/chat/conversation?id=${chatId}`);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Messages</Text>
        <TouchableOpacity style={styles.newChatButton}>
          <Plus size={24} color="#3B82F6" />
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <Search size={20} color="#64748B" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search conversations..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94A3B8"
          />
        </View>
      </View>

      {/* Chat List */}
      <ScrollView style={styles.chatList} showsVerticalScrollIndicator={false}>
        {filteredChats.map((chat) => (
          <TouchableOpacity
            key={chat.id}
            style={styles.chatItem}
            onPress={() => handleChatPress(chat.id)}
          >
            <View style={styles.avatarContainer}>
              <Image source={{ uri: chat.user.avatar }} style={styles.avatar} />
              {chat.user.isOnline && <View style={styles.onlineIndicator} />}
            </View>
            
            <View style={styles.chatContent}>
              <View style={styles.chatHeader}>
                <Text style={styles.userName}>{chat.user.name}</Text>
                <Text style={styles.messageTime}>{chat.lastMessage.time}</Text>
              </View>
              
              <Text style={styles.userTitle}>{chat.user.title}</Text>
              
              <View style={styles.messageContainer}>
                <Text 
                  style={[
                    styles.lastMessage,
                    !chat.lastMessage.isRead && chat.lastMessage.sender === 'them' && styles.unreadMessage
                  ]}
                  numberOfLines={2}
                >
                  {chat.lastMessage.text}
                </Text>
                
                <View style={styles.messageIndicators}>
                  {chat.unreadCount > 0 && (
                    <View style={styles.unreadBadge}>
                      <Text style={styles.unreadCount}>{chat.unreadCount}</Text>
                    </View>
                  )}
                  <TouchableOpacity style={styles.moreButton}>
                    <MoreHorizontal size={16} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  newChatButton: {
    padding: 8,
  },
  searchContainer: {
    padding: 16,
    backgroundColor: '#FFFFFF',
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1E293B',
  },
  chatList: {
    flex: 1,
  },
  chatItem: {
    flexDirection: 'row',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 16,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  chatContent: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  messageTime: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  userTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 8,
  },
  messageContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  lastMessage: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
    marginRight: 12,
  },
  unreadMessage: {
    color: '#1E293B',
    fontFamily: 'Inter-Medium',
  },
  messageIndicators: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  unreadBadge: {
    backgroundColor: '#3B82F6',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  unreadCount: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  moreButton: {
    padding: 4,
  },
});