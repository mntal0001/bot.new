import { Redirect } from 'expo-router';

export default function Index() {
  // Check if user is authenticated (this would normally check actual auth state)
  const isAuthenticated = false;

  if (isAuthenticated) {
    return <Redirect href="/(tabs)" />;
  }

  return <Redirect href="/auth" />;
}