// app/posts/[id].tsx
import React, { useState } from 'react';
import {
  View, Text, Image, FlatList, TextInput,
  TouchableOpacity, StyleSheet, Alert,
} from 'react-native';
import { useSearchParams } from 'expo-router';
import { Heart, MessageCircle } from 'lucide-react-native';

const mockPosts = {
  p1: {
    id: 'p1',
    user: { id: 'u1', name: 'John Founder', avatar: 'https://randomuser.me/api/portraits/men/32.jpg' },
    content: 'Excited to raise seed funding for EcoTrack 🚀🌱',
    image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg',
    likes: 12,
    comments: [
      { id: 'c1', user: { id: 'u2', name: 'Investor A' }, text: 'Amazing job!' },
      { id: 'c2', user: { id: 'u3', name: 'Investor B' }, text: 'How much equity?' },
    ],
  },
  // Add more posts...
};

export default function PostDetail() {
  const { id } = useSearchParams<{ id: string }>();
  const [post, setPost] = useState(mockPosts[id!]);

  const [commentText, setCommentText] = useState('');

  if (!post) return <Text>Post not found</Text>;

  const addComment = () => {
    if (!commentText.trim()) return;
    setPost({
      ...post,
      comments: [
        ...post.comments,
        { id: Date.now().toString(), user: { id: 'u1', name: 'You' }, text: commentText },
      ],
    });
    setCommentText('');
  };

  const likePost = () => setPost({ ...post, likes: post.likes + 1 });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: post.user.avatar }} style={styles.avatar} />
        <Text style={styles.username}>{post.user.name}</Text>
      </View>

      <Text style={styles.content}>{post.content}</Text>
      {post.image && <Image source={{ uri: post.image }} style={styles.image} />}

      <View style={styles.actions}>
        <TouchableOpacity onPress={likePost} style={styles.actionBtn}>
          <Heart size={20} color="red" />
          <Text style={styles.actionText}>{post.likes}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => {}} style={styles.actionBtn}>
          <MessageCircle size={20} color="#3B82F6" />
          <Text style={styles.actionText}>{post.comments.length}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.commentBox}>
        <TextInput
          style={styles.input}
          placeholder="Add a comment..."
          value={commentText}
          onChangeText={setCommentText}
        />
        <TouchableOpacity onPress={addComment}>
          <Text style={styles.sendBtn}>Send</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={post.comments}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.commentItem}>
            <Text style={styles.commentUser}>{item.user.name}:</Text>
            <Text style={styles.commentText}>{item.text}</Text>
          </View>
        )}
      />

      {/* Simple Ad Banner Placeholder */}
      <View style={styles.adBanner}>
        <Text style={styles.adText}>🅰️ Ad Banner</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#F8FAFC' },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  avatar: { width: 40, height: 40, borderRadius: 20 },
  username: { marginLeft: 12, fontSize: 16, fontWeight: '600' },
  content: { marginBottom: 16, fontSize: 16 },
  image: { width: '100%', height: 200, borderRadius: 8, marginBottom: 16 },
  actions: { flexDirection: 'row', marginBottom: 16 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', marginRight: 24 },
  actionText: { marginLeft: 8 },
  commentBox: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'center',
  },
  input: {
    flex: 1,
    backgroundColor: '#FFF',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  sendBtn: { marginLeft: 12, color: '#3B82F6', fontWeight: '600' },
  commentItem: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  commentUser: { fontWeight: '600', marginRight: 6 },
  commentText: {},
  adBanner: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    marginTop: 16,
    backgroundColor: '#E2E8F0',
    borderRadius: 8,
  },
  adText: { color: '#64748B' },
});
