// app/user/[id].tsx
import React, { useState } from 'react';
import { View, Text, Image, FlatList, StyleSheet } from 'react-native';
import { useSearchParams } from 'expo-router';

const mockUsers = {
  u2: { id: 'u2', name: 'Investor A', avatar: 'https://randomuser.me/api/portraits/women/44.jpg' },
  u3: { id: 'u3', name: 'Investor B', avatar: 'https://randomuser.me/api/portraits/men/55.jpg' },
};

const mockPosts = {
  u2: [{ id: 'p3', content: 'Really like EcoTrack!', likes: 5 }],
  u3: [{ id: 'p4', content: 'Looking forward to HealthAI updates.', likes: 3 }],
};

export default function UserProfile() {
  const { id } = useSearchParams<{ id: string }>();
  const user = mockUsers[id!] || { name: 'Unknown', avatar: '' };
  const posts = mockPosts[id!] || [];

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={{ uri: user.avatar }} style={styles.avatar} />
        <Text style={styles.name}>{user.name}</Text>
      </View>

      <FlatList
        data={posts}
        keyExtractor={item => item.id}
        ListHeaderComponent={<Text style={styles.sectionTitle}>Posts</Text>}
        renderItem={({ item }) => (
          <View style={styles.post}>
            <Text>{item.content}</Text>
            <Text style={styles.likes}>❤️ {item.likes}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { alignItems: 'center', padding: 24, backgroundColor: '#FFF' },
  avatar: { width: 100, height: 100, borderRadius: 50 },
  name: { fontSize: 20, fontWeight: '600', marginTop: 12 },
  sectionTitle: { marginTop: 16, marginLeft: 16, fontSize: 16, fontWeight: '600' },
  post: { backgroundColor: '#FFF', margin: 16, padding: 16, borderRadius: 12 },
  likes: { marginTop: 8, color: '#64748B' },
});
