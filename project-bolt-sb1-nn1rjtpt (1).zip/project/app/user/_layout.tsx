// app/user/_layout.tsx
import { Stack } from 'expo-router';

export default function UserLayout() {
  return (
    <Stack
      screenOptions={{
        headerTitle: 'User Profile',
        headerBackTitle: 'Back',
        headerStyle: { backgroundColor: '#FFF' },
        headerTintColor: '#3B82F6',
      }}
    />
  );
}
