import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { 
  ArrowLeft, 
  BarChart2, 
  DollarSign, 
  PieChart as PieChartIcon,
  Clock,
  Share2,
  Bookmark,
  MoreVertical
} from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LineChart, PieChart } from 'react-native-chart-kit';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

// Mock data - in a real app, you'd fetch this based on the ID
const mockInvestment = {
  id: '1',
  startup: { 
    name: 'EcoTrack', 
    logo: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg', 
    category: 'Sustainability',
    stage: 'Series A',
    founder: 'Sarah Chen',
    description: 'AI-powered carbon footprint analytics for businesses. Our platform helps enterprises measure, analyze, and reduce their environmental impact through machine learning and comprehensive data integration.'
  },
  investedAmount: 5000,
  equityPercentage: 2.5,
  currentValue: 6750,
  growth: 35,
  investmentDate: '2024-01-15',
  lastUpdate: '2024-06-29',
  performanceData: [5000, 5200, 5800, 6200, 6750],
  performanceLabels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
  valuationHistory: [
    { date: '2024-01-15', valuation: 200000 },
    { date: '2024-03-20', valuation: 220000 },
    { date: '2024-06-01', valuation: 270000 },
  ],
  news: [
    { date: '2024-05-15', title: 'EcoTrack raises $10M Series A', source: 'TechCrunch' },
    { date: '2024-04-02', title: 'EcoTrack partners with major retailers', source: 'Forbes' },
  ]
};

const chartConfig = {
  backgroundColor: "#ffffff",
  backgroundGradientFrom: "#ffffff",
  backgroundGradientTo: "#ffffff",
  decimalPlaces: 0,
  color: (opacity = 1) => `rgba(16, 185, 129, ${opacity})`,
  labelColor: (opacity = 1) => `rgba(30, 41, 59, ${opacity})`,
  style: {
    borderRadius: 16
  },
  propsForDots: {
    r: "4",
    strokeWidth: "2",
    stroke: "#10B981"
  }
};

export default function InvestmentDetails() {
  const { id } = useLocalSearchParams();
  
  // In a real app, you would fetch the investment data based on the ID
  const investment = mockInvestment;

  return (
    <ScrollView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Investment Details</Text>
        <View style={styles.headerIcons}>
          <TouchableOpacity style={styles.iconButton}>
            <Bookmark size={24} color="#1E293B" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton}>
            <Share2 size={24} color="#1E293B" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Startup Info */}
      <View style={styles.startupContainer}>
        <Image source={{ uri: investment.startup.logo }} style={styles.startupLogo} />
        <Text style={styles.startupName}>{investment.startup.name}</Text>
        <Text style={styles.startupCategory}>{investment.startup.category} • {investment.startup.stage}</Text>
      </View>

      {/* Performance Chart */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Performance</Text>
        <LineChart
          data={{
            labels: investment.performanceLabels,
            datasets: [
              {
                data: investment.performanceData,
                color: (opacity = 1) => `rgba(16, 185, 129, ${opacity})`,
                strokeWidth: 2
              }
            ]
          }}
          width={width - 40}
          height={220}
          chartConfig={chartConfig}
          bezier
          style={styles.chart}
        />
      </View>

      {/* Key Metrics */}
      <View style={styles.metricsContainer}>
        <View style={styles.metricCard}>
          <DollarSign size={24} color="#3B82F6" />
          <Text style={styles.metricLabel}>Invested</Text>
          <Text style={styles.metricValue}>${investment.investedAmount.toLocaleString()}</Text>
        </View>
        <View style={styles.metricCard}>
          <PieChartIcon size={24} color="#8B5CF6" />
          <Text style={styles.metricLabel}>Equity</Text>
          <Text style={styles.metricValue}>{investment.equityPercentage}%</Text>
        </View>
        <View style={styles.metricCard}>
          <BarChart2 size={24} color="#10B981" />
          <Text style={styles.metricLabel}>Current Value</Text>
          <Text style={styles.metricValue}>${investment.currentValue.toLocaleString()}</Text>
        </View>
      </View>

      {/* About Section */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>About</Text>
        <Text style={styles.descriptionText}>{investment.startup.description}</Text>
        <View style={styles.founderContainer}>
          <Text style={styles.founderLabel}>Founder:</Text>
          <Text style={styles.founderName}>{investment.startup.founder}</Text>
        </View>
      </View>

      {/* Valuation History */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Valuation History</Text>
        {investment.valuationHistory.map((item, index) => (
          <View key={index} style={styles.historyItem}>
            <Text style={styles.historyDate}>{item.date}</Text>
            <Text style={styles.historyValue}>${item.valuation.toLocaleString()}</Text>
          </View>
        ))}
      </View>

      {/* Recent News */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Recent News</Text>
        {investment.news.map((item, index) => (
          <View key={index} style={styles.newsItem}>
            <Text style={styles.newsDate}>{item.date}</Text>
            <Text style={styles.newsTitle}>{item.title}</Text>
            <Text style={styles.newsSource}>{item.source}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  headerIcons: {
    flexDirection: 'row',
  },
  iconButton: {
    padding: 8,
    marginLeft: 8,
  },
  startupContainer: {
    alignItems: 'center',
    marginVertical: 24,
  },
  startupLogo: {
    width: 80,
    height: 80,
    borderRadius: 16,
    marginBottom: 16,
  },
  startupName: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#1E293B',
    marginBottom: 4,
  },
  startupCategory: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 16,
  },
  chart: {
    borderRadius: 12,
    marginLeft: -20,
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  metricCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    width: '30%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  metricLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 8,
    marginBottom: 4,
  },
  metricValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  descriptionText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#475569',
    lineHeight: 24,
    marginBottom: 16,
  },
  founderContainer: {
    flexDirection: 'row',
    marginTop: 8,
  },
  founderLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginRight: 8,
  },
  founderName: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#475569',
  },
  historyItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  historyDate: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  historyValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
  },
  newsItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  newsDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 4,
  },
  newsTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1E293B',
    marginBottom: 4,
  },
  newsSource: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
});